#include "main.h"

void set_desiredYaw(float desiredYaw);

//void DC_PID(MPU6050_t *targetOrientation, MPU6050_t *stationaryOrientation);

void DCSetOutput(int Output, int MotorNum);

void initDCOutput(int MotorNum);
