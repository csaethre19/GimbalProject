#include <stdlib.h>
#include <math.h>

void process_eventTime(int eventTime, int rise0_or_faLL1, int PWM_channel);

int provide_channel(int PWM_channel);